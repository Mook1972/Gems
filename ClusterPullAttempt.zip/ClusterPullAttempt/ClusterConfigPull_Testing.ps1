﻿Import-Module FailoverClusters
Import-Module SQLServer
[system.reflection.assembly]::LoadWithPartialName("Microsoft.SqlServer.Smo")|Out-Null
[system.reflection.assembly]::LoadWithPartialName("Microsoft.SqlServer.SqlWmiManagement")|Out-Null
cls

$clusters = Get-Content -Path "E:\Mauro\ClusterPullAttempt\clusters.txt" 

#Clear-Content E:\Mauro\ClusterPullAttempt\output\*.csv

Invoke-Sqlcmd -query "TRUNCATE TABLE [PSIngestion].[dbo].[ClusterGroup];
                      TRUNCATE TABLE [PSIngestion].[dbo].[ClusterNodes];
                      TRUNCATE TABLE [PSIngestion].[dbo].[ClusterResources];
                      TRUNCATE TABLE [PSIngestion].[dbo].[ClusterTreshold]"  -ServerInstance "USMDCKDDB6674,1113" -Database PSIngestion

function Get-ClusterGroup {
          
    [CmdletBinding()]
    param
    (
        [Parameter(Position=1, Mandatory = $True, HelpMessage="Select cluster server", ValueFromPipeline = $true)]
        #[ValidateSet("")]
       #foreach ($sqlinstance in get-content "E:\PS_ServerLists\Servers_All.txt")
         $Server
         
    )
  
        # Checking module
        Try
        {
            Import-Module FailoverClusters -ErrorAction Stop
        }
        Catch
        {
            $_.Exception.Message
            Write-Output "Failover cluster module not installed!"
            Break
        }
  
        Write-Host "Processing $server" -ForegroundColor Green
       
            # Checking if server exist           
            $hostname = [System.Net.Dns]::GetHostAddresses($Server)    
       
                # Proceed if IP address found
                If($hostname.ipaddresstostring)
                
                {
                    # Check if cluster service is running
                    Try 
                    { 
                        If (!(Get-Service -ComputerName $Server |  Where-Object  {$_.Displayname -match "Cluster*"}).Status -eq "Running") {throw}
                       
                    }
                    Catch 
                    {
                        Write-Warning 'Cluster service is not "Running"'
                       # Read-Host -Prompt "Press Enter to exit..."
                       # Break
                    } 
  
                    Try
                    {
                        # If checks passed then get cluster information
                        Invoke-Command -ComputerName $Server -ErrorAction Stop -ScriptBlock{                   
                         
                        #    Write-Output "Checking cluster recources:"
                        #   Get-ClusterResource  | select cluster,ownernode,iscoreresource,name,resourcetype,state,characteristics | ft -auto
  
                           #Write-Output "Checking cluster owner nodes:"
                            Get-ClusterGroup # | Select-Object  -Property  cluster,Iscoregroup,ownernode,state,name  
                            # ConvertTo-Csv -NoTypeInformation| Set-Content -path \\USMDCKPAP6722\E$\Mauro\ClusterPullAttempt\output\ClusterGroup.csv  -Force
  
                            
                            # Write-SqlTableData -ServerInstance "USMDCKDDB6674,1113" -DatabaseName "PSIngestion" -SchemaName "dbo" -TableName "ClusterGroup" -Force
                          
                          #  Write-Output "Checking cluster nodes:"
                          #  Get-ClusterNode | select cluster,name,state,nodeweight | #ft -auto 
                           # Write-SqlTableData -ServerInstance "USMDCKDDB6674,1113" -DatabaseName "PSIngestion" -SchemaName "dbo" -TableName "ClusterNode" -Force
                        
  
                         #   Write-Output "Checking file share witness availablity:"
                         #   Get-ClusterResource | Where-Object  {$_.Name -eq "File Share Witness"}  | select cluster,name,state | ft -AutoSize
        
                          #  Write-Output "Checking cluster threshold settings:"
                          #  get-cluster | ft  *  -Auto
                                                   }
                    }
                    Catch
                    {
                        $_.Exception.Message
                        #Break
                    }
                }
                Else
                {
                    Write-Warning "Server does not exist"
                }
 }

 function Get-ClusterResources{
          
    [CmdletBinding()]
    param
    (
        [Parameter(Position=1, Mandatory = $True, HelpMessage="Select cluster server", ValueFromPipeline = $true)]
        #[ValidateSet("")]
       #foreach ($sqlinstance in get-content "E:\PS_ServerLists\Servers_All.txt")
         $Server
         
    )
  
        # Checking module
        Try
        {
            Import-Module FailoverClusters -ErrorAction Stop
        }
        Catch
        {
            $_.Exception.Message
            Write-Output "Failover cluster module not installed!"
            Break
        }
  
        Write-Host "Processing $server" -ForegroundColor Green
       
            # Checking if server exist           
            $hostname = [System.Net.Dns]::GetHostAddresses($Server)    
       
                # Proceed if IP address found
                If($hostname.ipaddresstostring)
                
                {
                    # Check if cluster service is running
                    Try 
                    { 
                        If (!(Get-Service -ComputerName $Server |  Where-Object  {$_.Displayname -match "Cluster*"}).Status -eq "Running") {throw}
                       
                    }
                    Catch 
                    {
                        Write-Warning 'Cluster service is not "Running"'
                       # Read-Host -Prompt "Press Enter to exit..."
                       # Break
                    } 
  
                    Try
                    {
                        # If checks passed then get cluster information
                        Invoke-Command -ComputerName $Server -ErrorAction Stop -ScriptBlock{                   
                         
                          #Write-Output "Checking cluster recources:"
                          Get-ClusterResource # | select cluster,ownernode,iscoreresource,name,resourcetype,state,characteristics 
  
                        
                                                   }
                    }
                    Catch
                    {
                        $_.Exception.Message
                        #Break
                    }
                }
                Else
                {
                    Write-Warning "Server does not exist"
                }
 }

 function Get-ClusterNodes {
          
    [CmdletBinding()]
    param
    (
        [Parameter(Position=1, Mandatory = $True, HelpMessage="Select cluster server", ValueFromPipeline = $true)]
        #[ValidateSet("")]
       #foreach ($sqlinstance in get-content "E:\PS_ServerLists\Servers_All.txt")
         $Server
         
    )
  
        # Checking module
        Try
        {
            Import-Module FailoverClusters -ErrorAction Stop
        }
        Catch
        {
            $_.Exception.Message
            Write-Output "Failover cluster module not installed!"
            Break
        }
  
        Write-Host "Processing $server" -ForegroundColor Green
       
            # Checking if server exist           
            $hostname = [System.Net.Dns]::GetHostAddresses($Server)    
       
                # Proceed if IP address found
                If($hostname.ipaddresstostring)
                
                {
                    # Check if cluster service is running
                    Try 
                    { 
                        If (!(Get-Service -ComputerName $Server |  Where-Object  {$_.Displayname -match "Cluster*"}).Status -eq "Running") {throw}
                       
                    }
                    Catch 
                    {
                        Write-Warning 'Cluster service is not "Running"'
                       # Read-Host -Prompt "Press Enter to exit..."
                       # Break
                    } 
  
                    Try
                    {
                        # If checks passed then get cluster information
                        Invoke-Command -ComputerName $Server -ErrorAction Stop -ScriptBlock{                   
                                                      
                         
                           #Write-Output "Checking cluster nodes:"
                          Get-ClusterNode # |  select cluster,name,state,nodeweight 
                                                  }
                    }
                    Catch
                    {
                        $_.Exception.Message
                        #Break
                    }
                }
                Else
                {
                    Write-Warning "Server does not exist"
                }
 }

 
function Get-ClusterTreshold  {
          
    [CmdletBinding()]
    param
    (
        [Parameter(Position=1, Mandatory = $True, HelpMessage="Select cluster server", ValueFromPipeline = $true)]
        #[ValidateSet("")]
       #foreach ($sqlinstance in get-content "E:\PS_ServerLists\Servers_All.txt")
         $Server
         
    )
  
        # Checking module
        Try
        {
            Import-Module FailoverClusters -ErrorAction Stop
        }
        Catch
        {
            $_.Exception.Message
            Write-Output "Failover cluster module not installed!"
            Break
        }
  
        Write-Host "Processing $server" -ForegroundColor Green
       
            # Checking if server exist           
            $hostname = [System.Net.Dns]::GetHostAddresses($Server)    
       
                # Proceed if IP address found
                If($hostname.ipaddresstostring)
                
                {
                    # Check if cluster service is running
                    Try 
                    { 
                        If (!(Get-Service -ComputerName $Server |  Where-Object  {$_.Displayname -match "Cluster*"}).Status -eq "Running") {throw}
                       
                    }
                    Catch 
                    {
                        Write-Warning 'Cluster service is not "Running"'
                       # Read-Host -Prompt "Press Enter to exit..."
                       # Break
                    } 
  
                    Try
                    {
                        # If checks passed then get cluster information
                        Invoke-Command -ComputerName $Server -ErrorAction Stop -ScriptBlock{                   
                         


                           #Write-Output "Checking cluster threshold settings:"
                             get-cluster # |   select Name,AddEvictDelay,AdministrativeAccessPoint,BackupInProgress,ClusSvcHangTimeout,ClusSvcRegroupOpeningTimeout,ClusSvcRegroupPruningTimeout,ClusSvcRegroupStageTimeout,ClusSvcRegroupTickInMilliseconds,ClusterGroupWaitDelay,MinimumNeverPreemptPriority,MinimumPreemptorPriority,ClusterEnforcedAntiAffinity,ClusterLogLevel ,ClusterLogSize,CrossSubnetDelay,CrossSubnetThreshold,DefaultNetworkRole,Description,FixQuorum,WitnessDynamicWeight,HangRecoveryAction,IgnorePersistentStateOnStartup,LogResourceControls,PlumbAllCrossSubnetRoutes,PreventQuorum,QuorumArbitrationTimeMax ,RequestReplyTimeout ,RootMemoryReserved,RouteHistoryLength,SameSubnetDelay,SameSubnetThreshold,SecurityLevel,SharedVolumeCompatibleFilters,SharedVolumeIncompatibleFilters,SharedVolumesRoot,SharedVolumeSecurityDescriptor,ShutdownTimeoutInMinutes,DrainOnShutdown,SharedVolumeVssWriterOperationTimeout,NetftIPSecEnabled,LowerQuorumPriorityNodeId,UseClientAccessNetworksForSharedVolumes,BlockCacheSize,WitnessDatabaseWriteTimeout,WitnessRestartInterva,RecentEventsResetTime,EnableSharedVolumes,DynamicQuorum,CsvBalancer,DatabaseReadWriteMode,MessageBufferLength,Id
                                                                    
                                                   }
                    }
                    Catch
                    {
                        $_.Exception.Message
                        #Break
                    }
                }
                Else
                {
                    Write-Warning "Server does not exist"
                }
 }


 foreach ($clus in $clusters) 
{Get-ClusterGroup  $clus | select cluster,Iscoregroup,ownernode,state,name  |  Where-Object {$_.name -ne 'Available Storage'} |
  #Export-Csv -Path E:\Mauro\ClusterPullAttempt\output\ClusterGroup.csv -NoTypeInformation  -Append -Force }
   Write-SqlTableData -ServerInstance "USMDCKDDB6674,1113" -DatabaseName PSIngestion -SchemaName dbo -TableName ClusterGroup  -force 
  }



   foreach ($clus in $clusters) 
{Get-ClusterResources $clus | select cluster,ownernode,iscoreresource,name,resourcetype,state,characteristics |
  #Export-Csv -Path E:\Mauro\ClusterPullAttempt\output\ClusterResources.csv -NoTypeInformation  -Append -Force  }
   Write-SqlTableData -ServerInstance "USMDCKDDB6674,1113" -DatabaseName PSIngestion -SchemaName dbo -TableName ClusterResources  -force 
  }

   
   foreach ($clus in $clusters) 
{Get-ClusterNodes $clus |   select cluster,name,state,nodeweight |
 #Export-Csv -Path E:\Mauro\ClusterPullAttempt\output\ClusterNodes.csv -NoTypeInformation  -Append -Force  }
  Write-SqlTableData -ServerInstance "USMDCKDDB6674,1113" -DatabaseName PSIngestion -SchemaName dbo -TableName ClusterNodes  -force 
  }

     foreach ($clus in $clusters) 
{Get-ClusterTreshold $clus | select Name,AddEvictDelay,AdministrativeAccessPoint,BackupInProgress,ClusSvcHangTimeout,ClusSvcRegroupOpeningTimeout,ClusSvcRegroupPruningTimeout,ClusSvcRegroupStageTimeout,ClusSvcRegroupTickInMilliseconds,ClusterGroupWaitDelay,MinimumNeverPreemptPriority,MinimumPreemptorPriority,ClusterEnforcedAntiAffinity,ClusterLogLevel,ClusterLogSize,CrossSubnetDelay,CrossSubnetThreshold,DefaultNetworkRole,Description,FixQuorum,WitnessDynamicWeight,HangRecoveryAction,IgnorePersistentStateOnStartup,LogResourceControls,PlumbAllCrossSubnetRoutes,PreventQuorum,QuorumArbitrationTimeMax,RequestReplyTimeout,RootMemoryReserved,RouteHistoryLength,SameSubnetDelay,SameSubnetThreshold,SecurityLevel,SharedVolumesRoot,SharedVolumeSecurityDescriptor,ShutdownTimeoutInMinutes,DrainOnShutdown,SharedVolumeVssWriterOperationTimeout,NetftIPSecEnabled,LowerQuorumPriorityNodeId,UseClientAccessNetworksForSharedVolumes,BlockCacheSize,WitnessDatabaseWriteTimeout,WitnessRestartInterva,RecentEventsResetTime,EnableSharedVolumes,DynamicQuorum,CsvBalancer,DatabaseReadWriteMode,MessageBufferLength,Id |
  Write-SqlTableData -ServerInstance "USMDCKDDB6674,1113" -DatabaseName PSIngestion -SchemaName dbo -TableName ClusterTreshold  -force      
  }                                          
 # Export-Csv -Path E:\Mauro\ClusterPullAttempt\output\ClusterTreshold.csv -NoTypeInformation  -Append -Force }

 # $values = Import-Csv -Path E:\Mauro\ClusterPullAttempt\output\ClusterResources.csv 
 # $values | Select-Object -First 100 | Out-GridView