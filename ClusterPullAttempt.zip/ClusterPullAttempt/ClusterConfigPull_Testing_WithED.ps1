﻿Import-Module FailoverClusters
Import-Module SQLServer
[system.reflection.assembly]::LoadWithPartialName("Microsoft.SqlServer.Smo")|Out-Null
[system.reflection.assembly]::LoadWithPartialName("Microsoft.SqlServer.SqlWmiManagement")|Out-Null
cls

$clusters = Get-Content -Path "E:\Mauro\ClusterPullAttempt\clusters.txt" 

#Clear-Content E:\Mauro\ClusterPullAttempt\output\*.csv

Invoke-Sqlcmd -query "TRUNCATE TABLE [PSIngestion].[dbo].[ClusterGroup];
                      TRUNCATE TABLE [PSIngestion].[dbo].[ClusterNodes];
                      TRUNCATE TABLE [PSIngestion].[dbo].[ClusterResources];
                      TRUNCATE TABLE [PSIngestion].[dbo].[ClusterTreshold]"  -ServerInstance "USMDCKDDB6674,1113" -Database PSIngestion


 foreach ($clus in $clusters) 
{Get-ClusterGroup  $clus | select cluster,Iscoregroup,ownernode,state,name  | Where-Object {$_.name -ne 'Available Storage'} |
  #Export-Csv -Path E:\Mauro\ClusterPullAttempt\output\ClusterGroup.csv -NoTypeInformation  -Append -Force }
   Write-SqlTableData -ServerInstance "USMDCKDDB6674,1113" -DatabaseName PSIngestion -SchemaName dbo -TableName ClusterGroup  -force 
  }



   foreach ($clus in $clusters) 
{Get-ClusterResources $clus | select cluster,ownernode,iscoreresource,name,resourcetype,state,characteristics |
  #Export-Csv -Path E:\Mauro\ClusterPullAttempt\output\ClusterResources.csv -NoTypeInformation  -Append -Force  }
   Write-SqlTableData -ServerInstance "USMDCKDDB6674,1113" -DatabaseName PSIngestion -SchemaName dbo -TableName ClusterResources  -force 
  }

   
   foreach ($clus in $clusters) 
{Get-ClusterNodes $clus |   select cluster,name,state,nodeweight |
 #Export-Csv -Path E:\Mauro\ClusterPullAttempt\output\ClusterNodes.csv -NoTypeInformation  -Append -Force  }
  Write-SqlTableData -ServerInstance "USMDCKDDB6674,1113" -DatabaseName PSIngestion -SchemaName dbo -TableName ClusterNodes  -force 
  }

     foreach ($clus in $clusters) 
{Get-ClusterTreshold $clus | select Name,AddEvictDelay,AdministrativeAccessPoint,BackupInProgress,ClusSvcHangTimeout,ClusSvcRegroupOpeningTimeout,ClusSvcRegroupPruningTimeout,ClusSvcRegroupStageTimeout,ClusSvcRegroupTickInMilliseconds,ClusterGroupWaitDelay,MinimumNeverPreemptPriority,MinimumPreemptorPriority,ClusterEnforcedAntiAffinity,ClusterLogLevel,ClusterLogSize,CrossSubnetDelay,CrossSubnetThreshold,DefaultNetworkRole,Description,FixQuorum,WitnessDynamicWeight,HangRecoveryAction,IgnorePersistentStateOnStartup,LogResourceControls,PlumbAllCrossSubnetRoutes,PreventQuorum,QuorumArbitrationTimeMax,RequestReplyTimeout,RootMemoryReserved,RouteHistoryLength,SameSubnetDelay,SameSubnetThreshold,SecurityLevel,SharedVolumesRoot,SharedVolumeSecurityDescriptor,ShutdownTimeoutInMinutes,DrainOnShutdown,SharedVolumeVssWriterOperationTimeout,NetftIPSecEnabled,LowerQuorumPriorityNodeId,UseClientAccessNetworksForSharedVolumes,BlockCacheSize,WitnessDatabaseWriteTimeout,WitnessRestartInterva,RecentEventsResetTime,EnableSharedVolumes,DynamicQuorum,CsvBalancer,DatabaseReadWriteMode,MessageBufferLength,Id |
  Write-SqlTableData -ServerInstance "USMDCKDDB6674,1113" -DatabaseName PSIngestion -SchemaName dbo -TableName ClusterTreshold  -force      
  }                                          
 # Export-Csv -Path E:\Mauro\ClusterPullAttempt\output\ClusterTreshold.csv -NoTypeInformation  -Append -Force }

 # $values = Import-Csv -Path E:\Mauro\ClusterPullAttempt\output\ClusterResources.csv 
 # $values | Select-Object -First 100 | Out-GridView