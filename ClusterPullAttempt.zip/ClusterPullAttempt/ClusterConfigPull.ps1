﻿
Import-Module FailoverClusters
Import-Module SQLServer
[system.reflection.assembly]::LoadWithPartialName("Microsoft.SqlServer.Smo")|Out-Null
[system.reflection.assembly]::LoadWithPartialName("Microsoft.SqlServer.SqlWmiManagement")|Out-Null
cls

$clusters = Get-Content -Path "E:\Mauro\ClusterPullAttempt\clusters.txt" 


function Get-ClusterData {
          
    [CmdletBinding()]
    param
    (
        [Parameter(Position=1, Mandatory = $True, HelpMessage="Select cluster server", ValueFromPipeline = $true)]
        #[ValidateSet("")]
       #foreach ($sqlinstance in get-content "E:\PS_ServerLists\Servers_All.txt")
         $Server
    )
  
        # Checking module
        Try
        {
            Import-Module FailoverClusters -ErrorAction Stop
        }
        Catch
        {
            $_.Exception.Message
            Write-Output "Failover cluster module not installed!"
            Break
        }
  
        Write-Host "Processing $server" -ForegroundColor Green
       
            # Checking if server exist           
            $hostname = [System.Net.Dns]::GetHostAddresses($Server)    
       
                # Proceed if IP address found
                If($hostname.ipaddresstostring)
                {
                    # Check if cluster service is running
                    Try 
                    { 
                        If (!(Get-Service -ComputerName $Server |  Where-Object  {$_.Displayname -match "Cluster*"}).Status -eq "Running") {throw}
                    }
                    Catch 
                    {
                        Write-Warning 'Cluster service is not "Running"'
                       # Read-Host -Prompt "Press Enter to exit..."
                       # Break
                    } 
  
                    Try
                    {
                        # If checks passed then get cluster information
                        Invoke-Command -ComputerName $Server -ErrorAction Stop -ScriptBlock{                   
                         
                            Write-Output "Checking cluster recources:"
                            Get-ClusterResource  | select cluster,ownernode,iscoreresource,name,resourcetype,state,characteristics | ft -auto
  
                            Write-Output "Checking cluster owner nodes:"
                            Get-ClusterGroup  | select cluster,Iscoregroup,ownernode,state,name | sort state |  ft -AutoSize 
                         
                            Write-Output "Checking cluster nodes:"
                            Get-ClusterNode | select cluster,name,state,nodeweight | ft -auto 
                      
                            Write-Output "Checking file share witness availablity:"
                      	    Get-ClusterResource | Where-Object  {$_.Name -eq "File Share Witness"}  | select cluster,name,state | ft -AutoSize
        
                            Write-Output "Checking cluster threshold settings:"
                            get-cluster | ft  *  -Auto
                                                   }
                    }
                    Catch
                    {
                        $_.Exception.Message
                        #Break
                    }
                }
                Else
                {
                    Write-Warning "Server does not exist"
                }
 }
 foreach ($clus in $clusters) 
 {Get-ClusterData  $clus }


