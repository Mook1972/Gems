﻿# Author - Edward J Pochinski III 03222019 epochinski@kpmg.com
# Purpose - This script will setup the TDE Keys across KCW AG Replicas
# This is for 4 nodes
# Check for comments to edit or create the share
CLS
Import-Module SqlServer
$PrimaryNode="USAZRKPCL10519" 
$sqlinstancePrim1="USAZRKPCL10519\KCW,1114"
$sqlinstancePrim2="USAZRKPCL10518\KCW,1114"
$sqlinstanceSecondary1="USAZRDPCL20008\KCW,1114"
$sqlinstanceSecondary2="USAZRDPCL20007\KCW,1114"
# Backs up the key & Cert files to G:\TDE_CERT create a TDE_CERT share see below
$SQLQuery_PrimaryKey_Certificate="USE master ;
 IF NOT EXISTS (SELECT 1 FROM sys.symmetric_keys WHERE name LIKE '%MS_DatabaseMasterKey%')
Begin 
CREATE MASTER KEY ENCRYPTION BY PASSWORD = 'KCW_PreProd_3ncrypt10n@Hrd2Gess' ; 
Print 'Master Encryption Key does not exist and is being created'
End
else
Print 'Master Encryption Key Exists and will not be created' 
USE master; 
IF NOT EXISTS (select 1 from sys.certificates  where name = 'TDECert_KCW_PreProd')
Begin
CREATE CERTIFICATE TDECert_KCW_PreProd WITH SUBJECT = 'TDECertificateKCW_PreProd'
End
else
Print 'Database Certificate exists and is not being created'
GO
--backup cert
BACKUP CERTIFICATE TDECert_KCW_PreProd TO FILE = 'G:\TDE_CERT\KCW_PreProd_TDECert.cert'
WITH PRIVATE KEY
(
FILE = 'G:\TDE_CERT\BackupEncryptPrivateKey_KCWPreProd.key',
ENCRYPTION BY PASSWORD = 'KCW_PreProd_3ncrypt10n@Hrd2Gess'
)
Print 'Database Cert backed up to disk'
"
# Note that the share created is on the primary replica where we read the files from
$SQLQuery_AGSecondary_Key_Certificate="
IF NOT EXISTS (SELECT 1 FROM sys.symmetric_keys WHERE name LIKE '%MS_DatabaseMasterKey%')
Begin 
CREATE MASTER KEY ENCRYPTION BY PASSWORD = 'KCW_PreProd_3ncrypt10n@Hrd2Gess'; 
Print 'Master Encryption Key does not exist and is being created'
End
else
Print 'Master Encryption Key Exists and will not be created';
IF NOT EXISTS (select 1 from sys.certificates  where name = 'TDECert_KCW_PreProd')
Begin
CREATE CERTIFICATE TDECert_KCW_PreProd  
FROM FILE = '\\USAZRKPCL10519\TDE_CERT\KCW_PreProd_TDECert.cert'    
WITH PRIVATE KEY (FILE = '\\USAZRKPCL10519\TDE_CERT\BackupEncryptPrivateKey_KCWPreProd.key', DECRYPTION BY PASSWORD = 'KCW_PreProd_3ncrypt10n@Hrd2Gess')
Print 'Database Certificate does not exist and is being created'
End
else
Print 'Database Certificate exists and is not being created'; 
"
Write-Host "Begining Deployment of the cert and keys on Replicas: $sqlinstancePrim1, $sqlinstancePrim2, $sqlinstanceSecondary1, $sqlinstanceSecondary2 " -Fore Green
Write-Host "Setting Seeding DATABASE Permissions on Replica: $sqlinstancePrim1" -Fore Yellow
	Invoke-Sqlcmd -ServerInstance $sqlinstancePrim1 -Database master -Query $SQLQuery_PrimaryKey_Certificate
Write-Host "Completed Deploying the cert and key on Replica: $sqlinstancePrim1" -Fore Green

Write-Host "Setting Seeding DATABASE Permissions on Replica: $sqlinstancePrim2" -Fore Yellow
	Invoke-Sqlcmd -ServerInstance $sqlinstancePrim2 -Database master -Query $SQLQuery_AGSecondary_Key_Certificate
Write-Host "Completed Deploying the cert and key on Replica: $sqlinstancePrim2" -Fore Green

Write-Host "Setting Seeding DATABASE Permissions on Replica: $sqlinstanceSecondary1" -Fore Yellow
    Invoke-Sqlcmd -ServerInstance $sqlinstanceSecondary1 -Database master -Query $SQLQuery_AGSecondary_Key_Certificate
Write-Host "Completed Deploying the cert and key on Replica: $sqlinstanceSecondary1" -Fore Green

Write-Host "Setting Seeding DATABASE Permissions on Replica: $sqlinstanceSecondary2" -Fore Yellow
    Invoke-Sqlcmd -ServerInstance $sqlinstanceSecondary2 -Database master -Query $SQLQuery_AGSecondary_Key_Certificate
Write-Host "Completed Deploying the cert and key on Replica: $sqlinstanceSecondary2" -Fore Green

Write-Host "Completed Deploying the cert and keys on Replicas: $sqlinstancePrim1, $sqlinstancePrim2, $sqlinstanceSecondary1, $sqlinstanceSecondary2 " -Fore Green
