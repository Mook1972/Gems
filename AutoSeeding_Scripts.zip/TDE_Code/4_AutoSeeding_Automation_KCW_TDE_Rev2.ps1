﻿CLS
# Author - Edward J Pochinski III 03222019 epochinski@kpmg.com
#add the databases to the AG Group Via Auto Seeding
$sqlinstancePrim1="USAZRKPCL10519\KCW,1114"
Write-Host "Performing the backup and seeding of new databases" -fore Magenta
Write-Host "Connecting to : " $sqlinstancePrim1 -fore Yellow
      Invoke-Sqlcmd -ServerInstance $sqlinstancePrim1 -verbose -Query "    
--# Autor - Edward J Pochinski III 03252019 epochinski@kpmg.com
--# Purpose - This script will deploy Databases with TDE and Auto seed to the replicas
--# This is Designed for 4 nodes as is
SET NOCOUNT ON
Declare @sqlstring nvarchar (555),@backuppath varchar(555),@sqlstring1 nvarchar (555),@sqlstring2 nvarchar(555)
DECLARE UserDBNotSyncd INSENSITIVE CURSOR 

    FOR  

Select TOP 1 Name from master..sysdatabases 
where name not in(
Select db_name(database_id) from sys.dm_hadr_database_replica_states)
and dbid > 5 --and name ='2cb09030-5b86-4db3-8b2f-b6a86ff4b3ef'--NOT LIKE '%-%'

	FOR READ ONLY 

   OPEN UserDBNotSyncd 

DECLARE @DBName varchar(50) 

       FETCH NEXT FROM UserDBNotSyncd INTO @DBName

           WHILE (@@FETCH_STATUS = 0) 

BEGIN
Print 'Checking if database is in simple recovery model and changing to Full'
select name, recovery_model_desc from sys.databases where recovery_model_desc = 'simple' and 
		name = @DBName
	If @@rowcount <> 0
	begin
 		set @script = 'alter database [' + @DBName + '] set recovery FULL'
  		exec sp_executesql @script
		print 'Database Recovery set to Full for: ' + @DBName		 
	end
Print 'Checking for database encryption key for :' + @DBname
SELECT db_name(database_id) [TDE Encrypted DB Name], c.name as CertName, encryptor_thumbprint 
FROM sys.dm_database_encryption_keys dek 
INNER JOIN sys.certificates c on dek.encryptor_thumbprint = c.thumbprint
where DB_NAME(database_id) = @DBName
If @@rowcount = 0
Begin
Print 'Creating Database Encryption Key it does not exist for: '  + @DBname
set @sqlstring2 =' USE [' + @DBName + ']; CREATE DATABASE ENCRYPTION KEY WITH ALGORITHM = AES_256 ENCRYPTION BY SERVER CERTIFICATE TDECert_KCW_PreProd;'
Print @sqlstring2 
EXECUTE sp_executesql @sqlstring2
End ELSE Print 'Database Already has an encryption Key: ' + @DBName
Print 'Checking if database is encrypted'
SELECT DB_NAME(database_id) AS DatabaseName, encryption_state,
encryption_state_desc =
CASE encryption_state
         WHEN '0'  THEN  'No database encryption key present, no encryption'
         WHEN '1'  THEN  'Unencrypted'
         WHEN '2'  THEN  'Encryption in progress'
         WHEN '3'  THEN  'Encrypted'
         WHEN '4'  THEN  'Key change in progress'
         WHEN '5'  THEN  'Decryption in progress'
         WHEN '6'  THEN  'Protection change in progress (The certificate or asymmetric key that is encrypting the database encryption key is being changed.)'
         ELSE 'No Status'
         END,
percent_complete,encryptor_thumbprint, encryptor_type  FROM sys.dm_database_encryption_keys
where DB_NAME(database_id) = @DBName and encryption_state = 3
If @@rowcount = 0
Begin
Print ' Encrypting Database: ' + @DBName
set @sqlstring1='ALTER DATABASE [' + @DBName + '] SET ENCRYPTION ON'
Print @sqlstring1
EXECUTE sp_executesql @sqlstring1
END Else Print ' Database is already encrypted: ' + @DBName + ' Adding to AG group next'
--Monitor the encryption process

Declare @dbid int,@encryptionstate int
Select @dbid = dbid from sysdatabases where name = @dbname
looper:
SELECT @encryptionstate = encryption_state FROM sys.dm_database_encryption_keys
                                WHERE database_id = @dbid;
								Print @encryptionstate
If @encryptionstate != 3
	Begin
	WAITFOR DELAY '00:00:06';
	Print 'Checking for Ecryption to complete and checking status'
GOTO looper
	End
Else
	Begin
	Print 'Encryption Process has Completed moving to adding to the AG Group now.'
	end



Print 'Backing up database: ' + @DBName
Set @backuppath = 'G:\Backup_Seeding_Staging\' +  @DBName + '.bak'
Backup Database @DBName TO DISK = @backuppath

Print 'Completed Database Backup to staging'
 
Print'*****Adding new database to AG Group for Auto Seeding:  ' + @DBName + ' ******' 
set @sqlstring=' ALTER AVAILABILITY GROUP AG_KCW ADD DATABASE [' + @DBName + '];'
 
 
Print @sqlstring
EXECUTE sp_executesql @sqlstring

If @@error = 0
Print 'Database Database Successfully added: ' + @DBName

FETCH NEXT FROM UserDBNotSyncd INTO   @DBName 
 END 

CLOSE UserDBNotSyncd 

DEALLOCATE UserDBNotSyncd

--cleanup backup staged files

Declare @cmdshellvalue sql_variant
select @cmdshellvalue = value_in_use from sys.configurations where name = 'xp_cmdshell'
If @cmdshellvalue = 0
Begin
Print 'Turning on xp_cmdshell,it magically was turned off somehow.'
exec sp_configure 'show advanced options','1'
RECONFIGURE WITH OVERRIDE
 exec sp_configure 'xp_cmdshell','1'
RECONFIGURE WITH OVERRIDE
END
waitfor Delay '00:00:05'
Print 'Cleaned up the full backup file from AG Prep & Auto Seeding'
exec xp_cmdshell ' del G:\Backup_Seeding_Staging\*.bak'
Print ''
Print 'The process has completed, refresh the AG Dash Board'  
" -querytimeout ([int]::MaxValue)

Write-Host "Completed Seeding Process" -fore Green