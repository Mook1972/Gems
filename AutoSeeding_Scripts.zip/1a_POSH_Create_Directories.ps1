# Author - Edward J Pochinski III 03222019 epochinski@kpmg.com
New-Item -path "G:\Backup_Seeding_Staging" -type directory
New-Item -path "G:\AutoSeeding_Scripts" -type directory
New-Item -path "G:\AutoSeeding_Scripts\JobScripts" -type directory
New-Item -path "G:\AGShare" -type directory
New-Item -path "G:\AutoSeed_Output" -type directory