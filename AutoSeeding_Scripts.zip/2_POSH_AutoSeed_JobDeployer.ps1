# Author - Edward J Pochinski III 03222019 epochinski@kpmg.com
# Deploys sql scripts to nodes
foreach ($sqlinstance in get-content "G:\AutoSeeding_Scripts\JobScripts\Servers.txt")

  {
             Write-Host "Processing Package on SQL Server: $sqlinstance" -Fore Green
Write-Host "Loading Initial AG Standard Permissions" -fore Magenta
Invoke-Sqlcmd -ServerInstance $sqlinstance -InputFile G:\AutoSeeding_Scripts\JobScripts\10_JobDeployer_Permissions_InitialAG.sql 
Write-Host "Loading 1st Job" -fore Magenta
Invoke-Sqlcmd -ServerInstance $sqlinstance -InputFile G:\AutoSeeding_Scripts\JobScripts\5_JobDeployer_AutoSeeding_Automation_Job.sql 
Write-Host "Loading 2nd Job" -fore Magenta
Invoke-Sqlcmd -ServerInstance $sqlinstance -InputFile G:\AutoSeeding_Scripts\JobScripts\6_JobDeployer_AutoSeedingJob_RoleWatcher.sql  
Write-Host "Loading 3nd Job" -fore Magenta
Invoke-Sqlcmd -ServerInstance $sqlinstance -InputFile G:\AutoSeeding_Scripts\JobScripts\7_JobDeployer_AG_WorkerThreadAlert_JobScript.sql  
Write-Host "Loading 4th Job" -fore Magenta
Invoke-Sqlcmd -ServerInstance $sqlinstance -InputFile G:\AutoSeeding_Scripts\JobScripts\8_JobDeployer_AutoSeedingOrphanedDatabaseOnSecondary_Monitor.sql 
Write-Host "Loading Database Mail" -fore Magenta
Invoke-Sqlcmd -ServerInstance $sqlinstance -InputFile G:\AutoSeeding_Scripts\JobScripts\9_JobDeployer_DBMail_Setup.sql  
Write-Host "Processing Packages on SQL Server: $sqlinstance" -Fore Green
}
