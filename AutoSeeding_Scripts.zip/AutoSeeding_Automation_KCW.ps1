﻿CLS
#add the databases to the AG Group Via Auto Seeding
$sqlinstancePrim1="USAZRKPCL10519\KCW,1114"
Write-Host "Performing the backup and seeding of new databases" -fore Magenta
Write-Host "Connecting to : " $sqlinstancePrim1 -fore Yellow
      Invoke-Sqlcmd -ServerInstance $sqlinstancePrim1 -verbose -Query " 
declare @name sysname,
	@recovery_model_desc nvarchar(120),
	@script nvarchar(500) 
Declare @sqlstring nvarchar (555),@backuppath varchar(555)

DECLARE UserDBNotSyncd INSENSITIVE CURSOR 

    FOR  

Select TOP 1 Name from master..sysdatabases 
where name not in(
Select db_name(database_id) from sys.dm_hadr_database_replica_states)
and dbid > 5

	FOR READ ONLY 

   OPEN UserDBNotSyncd 

DECLARE @DBName varchar(50) 

       FETCH NEXT FROM UserDBNotSyncd INTO @DBName

           WHILE (@@FETCH_STATUS = 0) 

BEGIN 

	select name, recovery_model_desc from sys.databases where recovery_model_desc = 'simple' and 
		name = @DBName
	If @@rowcount <> 0
	begin
 		set @script = 'alter database [' + @DBName + '] set recovery FULL'
  		exec sp_executesql @script
		print 'Database Recovery set to Full for: ' + @DBName		 
	end
--WAITFOR DELAY '00:00:04'
Print 'Backing up database: ' + @DBName
Set @backuppath = 'G:\Backup_Seeding_Staging\' +  @DBName + '.bak'
Backup Database @DBName TO DISK = @backuppath

Print 'Completed Database Backup to staging'
 
Print'*****Adding new database to AG Group for Auto Seeding:  ' + @DBName + ' ******' 
set @sqlstring=' ALTER AVAILABILITY GROUP AG_KCW ADD DATABASE [' + @DBName + '];'
 
 
Print @sqlstring
EXECUTE sp_executesql @sqlstring

If @@error = 0
Print 'Database Database Successfully added: ' + @DBName

FETCH NEXT FROM UserDBNotSyncd INTO   @DBName 
 END 

CLOSE UserDBNotSyncd 

DEALLOCATE UserDBNotSyncd

--cleanup backup staged files

Declare @cmdshellvalue sql_variant
select @cmdshellvalue = value_in_use from sys.configurations where name = 'xp_cmdshell'
If @cmdshellvalue = 0
Begin
Print 'Turning on xp_cmdshell,it magically was turned off somehow.'
exec sp_configure 'show advanced options','1'
RECONFIGURE WITH OVERRIDE
 exec sp_configure 'xp_cmdshell','1'
RECONFIGURE WITH OVERRIDE
END
waitfor Delay '00:00:05'
Print 'Cleanup the stagged full backup files from auto seeding'
exec xp_cmdshell ' del G:\Backup_Seeding_Staging\*.bak' 
"
Write-Host "Completed Seeding Process" -fore Green