﻿CLS
# Author - Edward J Pochinski III 03222019 epochinski@kpmg.com
#add the databases to the AG Group Via Auto Seeding
#******Edit replica name and port below******
$SQL_Replica1="USAZRKNCL10610\CATALOGDB,1113"
$HostShareName=hostname 
Write-Host $HosttShareName

Write-Host "Performing the backup and seeding of new databases" -fore Magenta
Write-Host "Connecting to : " $SQL_Replica1 -fore Yellow
      Invoke-Sqlcmd -ServerInstance $SQL_Replica1 -verbose -Query "    

--# Purpose - This script will deploy DBs and Auto seed to the replicas

SET NOCOUNT ON

declare @name sysname,
	@recovery_model_desc nvarchar(120),
	@script nvarchar(500)
declare db cursor 
	for 
	select name, recovery_model_desc from sys.databases where recovery_model_desc = 'simple' and 
		database_id > 4
	for read only
open db
	fetch next from db into @name, @recovery_model_desc
	while @@fetch_status = 0
	begin
 		set @script = 'alter database [' + @name + '] set recovery FULL'
  		exec sp_executesql @script
		print 'Database Recovery set to Full for: ' + @name
		fetch next from db into @name, @recovery_model_desc
	end
close db
deallocate db 

Declare @sqlstring nvarchar (555),@backuppath varchar(555),@sqlstring1 nvarchar (555),@sqlstring2 nvarchar(555)
DECLARE UserDBNotSyncd INSENSITIVE CURSOR 

    FOR  

Select TOP 1 Name from master..sysdatabases 
where name not in(
Select db_name(database_id) from sys.dm_hadr_database_replica_states)
and dbid > 5 
 

	FOR READ ONLY 

   OPEN UserDBNotSyncd 

DECLARE @DBName varchar(50) 

       FETCH NEXT FROM UserDBNotSyncd INTO @DBName

           WHILE (@@FETCH_STATUS = 0) 

BEGIN

    Print 'Backing up database: ' + @DBName
	Set @backuppath = '\\$HostShareName\Backup_Seeding_Staging\' +  @DBName + '.bak'
	Backup Database @DBName TO DISK = @backuppath

    Print 'Completed Database Backup to staging'
 
    Print'*****Adding new database to AG Group for Auto Seeding:  ' + @DBName + ' ******' 
    set @sqlstring=' ALTER AVAILABILITY GROUP AG_CATALOGDB ADD DATABASE [' + @DBName + '];'
 
 
    Print @sqlstring
    EXECUTE sp_executesql @sqlstring

    If @@error = 0
    Print 'Database Database Successfully added: ' + @DBName

    FETCH NEXT FROM UserDBNotSyncd INTO   @DBName 
END 

CLOSE UserDBNotSyncd 

DEALLOCATE UserDBNotSyncd

--cleanup backup staged files

Declare @cmdshellvalue sql_variant
select @cmdshellvalue = value_in_use from sys.configurations where name = 'xp_cmdshell'
If @cmdshellvalue = 0
Begin
Print 'Turning on xp_cmdshell,it magically was turned off somehow.'
exec sp_configure 'show advanced options','1'
RECONFIGURE WITH OVERRIDE
 exec sp_configure 'xp_cmdshell','1'
RECONFIGURE WITH OVERRIDE
END
waitfor Delay '00:00:02'
Print 'Cleaned up the full backup file from AG Prep & Auto Seeding'
exec xp_cmdshell ' del \\$HostShareName\Backup_Seeding_Staging\*.bak'
Print ''
Print 'The process has completed, refresh the AG Dash Board'  
" -querytimeout ([int]::MaxValue)

Write-Host "Completed Seeding Process" -fore Green 
