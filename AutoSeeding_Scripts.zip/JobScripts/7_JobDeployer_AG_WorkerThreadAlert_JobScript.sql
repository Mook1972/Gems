-- Author - Edward J Pochinski III 03222019 epochinski@kpmg.com
USE [msdb]
GO

/****** Object:  Job [AG_WorkerThreadAlert]    Script Date: 5/15/2019 5:49:49 PM ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [[Uncategorized (Local)]]    Script Date: 5/15/2019 5:49:49 PM ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'[Uncategorized (Local)]' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'[Uncategorized (Local)]'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

Declare @sasid varchar(25)
select @sasid = name from master..syslogins where sid = 0x01

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'AG_WorkerThreadAlert', 
		@enabled=0, 
		@notify_level_eventlog=0, 
		@notify_level_email=0, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'No description available.', 
		@category_name=N'[Uncategorized (Local)]', 
		@owner_login_name= @sasid, @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Call_WatcherScript]    Script Date: 5/15/2019 5:49:49 PM ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Call_WatcherScript', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'--Author - Ed Pochinski 04232019
--Purpose - AG Worker thread alert
--SSC posting copy
Declare @availableThreads varchar(25), @workers_waitingForCPU varchar(25), @Request_waiting_ForThread varchar(25),@msgbody varchar(500), @msgsubject varchar(500)
Select @availableThreads = (select  max_workers_count from sys.dm_os_sys_info)-sum(active_Workers_count) from  sys.dm_os_Schedulers where status=''VISIBLE ONLINE''
Print @availableThreads
Select @workers_waitingForCPU = sum(runnable_tasks_count) from  sys.dm_os_Schedulers where status=''VISIBLE ONLINE''
Print @workers_waitingForCPU
Select @Request_waiting_ForThread = sum(work_queue_count)  from  sys.dm_os_Schedulers where status=''VISIBLE ONLINE''
Print @Request_waiting_ForThread
--edit threshold to accomodate this is a test machine with no load so the humber is high to facilitate the alert 
If @availableThreads <=100 
Begin
Print '' Send a email alert here !!!!! Worker threads are low: '' + @availableThreads + '', Workers Waiting on CPU: '' + @workers_waitingForCPU + '' \ Requests Waiting for thread: '' + @Request_waiting_ForThread
set @msgbody =''Worker threads are low on Server: '' + @@servername + '' - Available Thread Count: '' + @availableThreads 
set @msgbody = @msgbody + char(13);
set @msgbody = @msgbody + '' - Worker Threads Waiting on CPU count: '' + @workers_waitingForCPU + char(10);
set @msgbody = @msgbody + '' - Requests Waiting for worker thread count: '' + @Request_waiting_ForThread
set @msgsubject = ''!!! AG Worker Thread Alert on SQL Server: '' + @@servername + '' !!!''
EXEC msdb.dbo.sp_send_dbmail
@recipients =N''epochinski@kpmg.com;dabraham@kpmg.com;rdigilio@kpmg.com'',
@body = @msgbody,
@subject =@msgsubject ,
@profile_name =''DMG_SQLDBA_Public_Profile''
End', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'Sched1', 
		@enabled=1, 
		@freq_type=4, 
		@freq_interval=1, 
		@freq_subday_type=4, 
		@freq_subday_interval=3, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=0, 
		@active_start_date=20190515, 
		@active_end_date=99991231, 
		@active_start_time=0, 
		@active_end_time=235959, 
		@schedule_uid=N'76779101-b0ba-4a5b-b830-e9f7708f3a25'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:

GO

