-- Author - Edward J Pochinski III 03222019 epochinski@kpmg.com
USE [msdb]
GO

/****** Object:  Job [AutoSeedingOrphanedDatabaseOnSecondary_Monitor]    Script Date: 5/15/2019 5:51:02 PM ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [[Uncategorized (Local)]]    Script Date: 5/15/2019 5:51:02 PM ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'[Uncategorized (Local)]' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'[Uncategorized (Local)]'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

Declare @sasid varchar(25)
select @sasid = name from master..syslogins where sid = 0x01

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'AutoSeedingOrphanedDatabaseOnSecondary_Monitor', 
		@enabled=0, 
		@notify_level_eventlog=0, 
		@notify_level_email=0, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'No description available.', 
		@category_name=N'[Uncategorized (Local)]', 
		@owner_login_name= @sasid, @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [CallMonitorCode]    Script Date: 5/15/2019 5:51:02 PM ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'CallMonitorCode', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'--Check for databases not syncronized on a se3condary replica
Set NOCOUNT ON 
Declare @isprimary varchar(255)
Select @isprimary = role_desc from sys.dm_hadr_availability_replica_states
where is_local =1  
--Select @isprimary
If @isprimary = ''Secondary''
Begin
SET NOCOUNT ON
	Select TOP 1 Name from master..sysdatabases 
	where name not in(
	Select db_name(database_id) from sys.dm_hadr_database_replica_states)
	and dbid > 5 
	if @@rowcount <> 0 --1 row returned denotes there is an Orphaned non seeded db present
	Begin
	WAITFOR DELAY ''00:00:30'' ---- 45 Second Delay
	END
	SET NOCOUNT ON
	Select TOP 1 Name from master..sysdatabases 
	where name not in(
	Select db_name(database_id) from sys.dm_hadr_database_replica_states)
	and dbid > 5 
	if @@rowcount <> 0 --1 row returned denotes there is an Orphaned non seeded db present
	Begin
		Print ''Send DB Mail alert''
		
		Declare @srvname varchar(55),@subject1 varchar(255)
Select @srvname = @@servername
DECLARE @xml NVARCHAR(MAX)
DECLARE @body NVARCHAR(MAX)
SET @body =''<html><H2>ALERT Orphaned databases that were not seeded
and failover may have took place. On Server: ''+ @srvname +'' please investigate</H2></html>''
Set @subject1 = ''Orphaned Databases detected on Secondary: '' + @srvname
EXEC msdb.dbo.sp_send_dbmail
@recipients =N''epochinski@kpmg.com;dabraham@kpmg.com;rdigilio@kpmg.com'',
@body = @body,@body_format =''HTML'',
@subject = @subject1 ,
@query=''SET NOCOUNT ON
	Select Name from master..sysdatabases 
	where name not in(
	Select db_name(database_id) from sys.dm_hadr_database_replica_states)
	and dbid > 5'',
	@query_result_header = 0,
@exclude_query_output = 1,
@append_query_error = 1,
@attach_query_result_as_file = 1,
@query_attachment_filename = ''Orphaned_Databases_qry.txt'',
@query_result_no_padding = 1,
@profile_name =''DMG_SQLDBA_Public_Profile''
		Print ''Databases are not syncd up and this node is secondary''
		Print ''This is where you send an email alert out as High Priority''
	End
	ELSE
	Begin
	Print ''Secondary Role and no issues''
	END

END
else
Print ''Primary Role''
', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'Sched1', 
		@enabled=1, 
		@freq_type=4, 
		@freq_interval=1, 
		@freq_subday_type=4, 
		@freq_subday_interval=4, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=0, 
		@active_start_date=20190513, 
		@active_end_date=99991231, 
		@active_start_time=0, 
		@active_end_time=235959, 
		@schedule_uid=N'fc46ef0e-9d7d-4c3d-9098-bda4fb0912cd'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:

GO

