-- Author - Edward J Pochinski III 03222019 epochinski@kpmg.com
--enable the DB Mail

sp_configure 'show advanced options','1'
go
RECONFIGURE WITH OVERRIDE
go
sp_configure 'Database Mail XPs','1'
go
RECONFIGURE WITH OVERRIDE
GO

/********************************************************************************/

Declare @srvname varchar(55)
Select @srvname = @@servername
Set @srvname = Replace(@srvname,'\','_')
Set @srvname = @srvname + '@kpmg.com'
--Print @srvname
-- Create Database Mail Account
EXECUTE msdb.dbo.sysmail_add_account_sp
    @account_name = 'DMG_SQLDBA_Public_Mail',
    @description = 'Mail account for DMG.',
    @email_address = @srvname,
    @replyto_address = @srvname,
    @display_name = 'Sent From DMG DBMail',
    @mailserver_name = 'smtpout' ;

-- Create a Database Mail profile
EXECUTE msdb.dbo.sysmail_add_profile_sp
    @profile_name = 'DMG_SQLDBA_Public_Profile',
    @description = 'Profile used for the DMG DBA.';

-- Add the account to the profile
EXECUTE msdb.dbo.sysmail_add_profileaccount_sp
    @profile_name = 'DMG_SQLDBA_Public_Profile',
    @account_name = 'DMG_SQLDBA_Public_Mail',
    @sequence_number = 1 ;

-- Grant access to the profile to the DBMailUsers role 
EXECUTE msdb.dbo.sysmail_add_principalprofile_sp
    @profile_name = 'DMG_SQLDBA_Public_Profile',
    @principal_name = 'Public',
    @is_default = 1 ;
	If @@error = 0
Print 'DB Mail Successfully Loaded'
else
Print ' An Error has taken place please review the error details'

EXECUTE msdb.dbo.sysmail_configure_sp 'ProhibitedExtensions', 
'BAT,DOS,CEO,CHM,CLASS,CMD,COM,CPL,EML,EXE,HLP,HTA,INF,INS,IE,JS,JSE,LNK,MSI,MSP,NWS,PIF,REG,SCR,SHS,SWF,SYS,VB,VBE,VBS,WSC,WSF,WSH' ;
Print 'Changing the default 1mb attachment to 5mb'
EXECUTE msdb.dbo.sysmail_configure_sp
    'MaxFileSize', '5242880' ;


If @@error = 0
Print 'Attachment Size changed from 1mb to 5mb successfully'
else
Print ' Code failed attachment size not altered'

Print ''
Print 'Turning on DB Mail XPs'
exec sp_configure 'Database Mail XPs','1'
go
RECONFIGURE WITH OVERRIDE
GO
Print 'Mail Template Package applied successfully'