-- Author - Edward J Pochinski III 03222019 epochinski@kpmg.com
--Identify and add the service account

Set NOCOUNT ON

Declare	@SQLSrvAccount nvarchar(255), @grant1 nvarchar(500),@grant2 nvarchar(500),@grant3 nvarchar(500)

SELECT	@SQLSrvAccount = service_account
FROM	sys.dm_server_services where servicename NOT LIKE '%Agent%'

Print @SQLSrvAccount

Set @grant1 = 'GRANT ALTER ANY AVAILABILITY GROUP TO [' + @SQLSrvAccount + ']'
 EXECUTE sp_executesql @grant1
Set @grant2 = 'GRANT CONNECT SQL TO [' + @SQLSrvAccount + ']'
 EXECUTE sp_executesql @grant2
Set @grant3 =  'GRANT VIEW SERVER STATE TO  [' + @SQLSrvAccount + ']'
 EXECUTE sp_executesql @grant3

GRANT ALTER ANY AVAILABILITY GROUP TO [NT AUTHORITY\SYSTEM]; 
GRANT CONNECT SQL TO [NT AUTHORITY\SYSTEM];  
GRANT VIEW SERVER STATE TO [NT AUTHORITY\SYSTEM];

If @@error = 0
Print 'Grants completed and moving on to'

Declare @adminsqlaccount nvarchar(255), @endpointownerchange nvarchar(500)
select  @adminsqlaccount = name from syslogins where sid = 0x01

Set NOCOUNT ON
USE [master];
SELECT	SUSER_NAME(principal_id) AS endpoint_owner, name AS endpoint_name
FROM	sys.database_mirroring_endpoints where SUSER_NAME(principal_id)  <>  @adminsqlaccount

If @@ROWCOUNT <> 0
Begin
	Print 'End Point Not Owned by SQLADMIN' 
	set @endpointownerchange =' AUTHORIZATION ON ENDPOINT::hadr_endpoint TO ' + @adminsqlaccount
	EXECUTE sp_executesql @endpointownerchange
	If @@error = 0
		Print ' End Point Owner changed to ' + @adminsqlaccount
	else Print 'It tanked, alter authorization failed'
End  
	Else Print @adminsqlaccount + ' Owns the end point nothing changed'