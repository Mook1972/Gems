# Author - Edward J Pochinski III 03222019 epochinski@kpmg.com
CLS
Import-Module SqlServer 
$sqlinstancePrim1="USAZRKSCL10502\KCW,1113"
$sqlinstancePrim2="USAZRKSCL10503\KCW,1113"
$sqlinstanceSecondary1="USAZRDSCL20002\KCW,1113"
$sqlinstanceSecondary2="USAZRDSCL20001\KCW,1113"
Write-Host "Launching the Automatic Seeding Permissions across the replicas: $sqlinstancePrim1, $sqlinstancePrim2, $sqlinstanceSecondary1, $sqlinstanceSecondary2 " -Fore Green
#edit correct AG Group if needed edit nodes\replicas to set the seeding to automatic
$SQLQuery_SetAutoSeeding1= "ALTER AVAILABILITY GROUP [AG_KCW] MODIFY REPLICA ON 'USAZRKSCL10502\KCW' WITH ( SEEDING_MODE = AUTOMATIC );"
$SQLQuery_SetAutoSeeding2= "ALTER AVAILABILITY GROUP [AG_KCW] MODIFY REPLICA ON 'USAZRKSCL10503\KCW' WITH ( SEEDING_MODE = AUTOMATIC );"
$SQLQuery_SetAutoSeeding3= "ALTER AVAILABILITY GROUP [AG_KCW] MODIFY REPLICA ON 'USAZRDSCL20001\KCW' WITH ( SEEDING_MODE = AUTOMATIC );"
$SQLQuery_SetAutoSeeding4= "ALTER AVAILABILITY GROUP [AG_KCW] MODIFY REPLICA ON 'USAZRDSCL20002\KCW' WITH ( SEEDING_MODE = AUTOMATIC );"
Write-Host "Setting Seeding Mode for Replica: $sqlinstancePrim1" -Fore Yellow
	Invoke-Sqlcmd -ServerInstance $sqlinstancePrim1 -Database master -Query $SQLQuery_SetAutoSeeding1
Write-Host "Setting Seeding Mode for Replica: $sqlinstancePrim2" -Fore Yellow
    Invoke-Sqlcmd -ServerInstance $sqlinstancePrim1 -Database master -Query $SQLQuery_SetAutoSeeding2
    Write-Host "Setting Seeding Mode for Replica: $sqlinstanceSecondary1" -Fore Yellow
    Invoke-Sqlcmd -ServerInstance $sqlinstancePrim1 -Database master -Query $SQLQuery_SetAutoSeeding3
Write-Host "Setting Seeding Mode for Replica: $sqlinstanceSecondary2" -Fore Yellow
    Invoke-Sqlcmd -ServerInstance $sqlinstancePrim1 -Database master -Query $SQLQuery_SetAutoSeeding4
Write-Host "Completed Seeding Mode on Replicas: $sqlinstancePrim1, $sqlinstancePrim2, $sqlinstanceSecondary1, $sqlinstanceSecondary2 " -Fore Green
Write-Host ""

Write-Host "Setting up the Create any database permissions for the AG Group across Replicas" -fore Yellow

$SQLQuery_AGCreateDBPerms="ALTER AVAILABILITY GROUP [AG_KCW] GRANT CREATE ANY DATABASE"

Write-Host "Setting Seeding DATABASE Permissions on Replica: $sqlinstancePrim1" -Fore Yellow
	Invoke-Sqlcmd -ServerInstance $sqlinstancePrim1 -Database master -Query $SQLQuery_AGCreateDBPerms
Write-Host "Completed DATABASE Permissions setup on Replica: $sqlinstancePrim1" -Fore Green

Write-Host "Setting Seeding DATABASE Permissions on Replica: $sqlinstancePrim2" -Fore Yellow
	Invoke-Sqlcmd -ServerInstance $sqlinstancePrim2 -Database master -Query $SQLQuery_AGCreateDBPerms
Write-Host "Completed DATABASE Permissions setup on Replica: $sqlinstancePrim2" -Fore Green

Write-Host "Setting Seeding DATABASE Permissions on Replica: $sqlinstanceSecondary1" -Fore Yellow
    Invoke-Sqlcmd -ServerInstance $sqlinstanceSecondary1 -Database master -Query $SQLQuery_AGCreateDBPerms
Write-Host "Completed DATABASE Permissions setup on Replica: $sqlinstanceSecondary1" -Fore Green

Write-Host "Setting Seeding DATABASE Permissions on Replica: $sqlinstanceSecondary2" -Fore Yellow
    Invoke-Sqlcmd -ServerInstance $sqlinstanceSecondary2 -Database master -Query $SQLQuery_AGCreateDBPerms
Write-Host "Completed DATABASE Permissions on Replica: $sqlinstanceSecondary2" -Fore Green

Write-Host "Completed Alter AG Group Create Database on Replicas: $sqlinstancePrim1, $sqlinstancePrim2, $sqlinstanceSecondary1, $sqlinstanceSecondary2 " -Fore Green








